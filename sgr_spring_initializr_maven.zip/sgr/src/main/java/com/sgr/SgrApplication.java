package com.sgr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SgrApplication {

	public static void main(String[] args) {
		SpringApplication.run(SgrApplication.class, args);
	}

}
