package com.sgr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SgrApplicationTests {

	@Test
	void contextLoads() {
	}

}
